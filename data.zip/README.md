# Hybrid Search Engine

A high-performance search engine that combines **semantic understanding** (what you mean) with **lexical matching** (what you typed) for superior search results.

## What It Does

Traditional keyword search fails when users don't know the exact terms. Pure semantic search misses exact matches. This engine combines both:

```
Query: "how to start a project"
├── Semantic: finds "A journey of a thousand miles begins with a single step"
├── Lexical: finds documents containing "start" and "project"
└── Hybrid: ranks results using both signals (configurable weights)
```

## Features

- **Hybrid Search** - Weighted combination of vector similarity + fuzzy text matching
- **FAISS Support** - Approximate nearest neighbor for million-scale datasets
- **Auto-Reindexing** - File watcher triggers reindex when documents change
- **Learning Weights** - Tracks user feedback to optimize semantic/lexical balance
- **REST API** - FastAPI endpoints for integration
- **Multi-Format Ingestion** - Loads `.txt`, `.md`, `.json`, `.log`, `.csv` from directories

## Quick Start

```bash
# Install
pip install -r requirements.txt

# Run demo
python main.py

# Or start API server
uvicorn search_engine.api:app --reload --port 8000
```

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Documents  │────▶│   Indexer   │────▶│   DuckDB    │
└─────────────┘     │  + Embedder │     │  + FAISS    │
                    └─────────────┘     └─────────────┘
                                              │
┌─────────────┐     ┌─────────────┐           │
│    Query    │────▶│   Searcher  │◀──────────┘
└─────────────┘     │  (Hybrid)   │
                    └─────────────┘
                          │
              ┌───────────┴───────────┐
              ▼                       ▼
        Semantic Score          Lexical Score
        (cosine sim)            (fuzzy + tokens)
              │                       │
              └───────┬───────────────┘
                      ▼
                Hybrid Score
              (weighted sum)
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/search` | POST | Hybrid search with configurable weights |
| `/search/batch` | POST | Multiple queries in one request |
| `/search/highlighted` | POST | Search with highlighted snippets |
| `/ask` | POST | RAG - answer questions using documents |
| `/rerank` | POST | Rerank results with cross-encoder |
| `/index` | POST | Index documents from request body |
| `/index/directory` | POST | Index all files from a directory |
| `/index/add` | POST | Add to existing index |
| `/feedback` | POST | Submit relevance feedback for learning |
| `/watcher/start` | POST | Start auto-reindex file watcher |
| `/watcher/stop` | POST | Stop file watcher |
| `/stats` | GET | Query and feedback statistics |
| `/documents` | GET | List indexed documents |
| `/health` | GET | Health check |

## Configuration

```python
# Search with custom weights
results = searcher.search(
    query="machine learning",
    docs_df=docs_df,
    vectors=vectors,
    top_k=10,
    semantic_weight=0.8,  # Emphasize meaning
    lexical_weight=0.2
)

# Or use learned weights from feedback
results = searcher.search(
    query="...",
    use_learned_weights=True  # Uses feedback history
)
```

---

## Future Enhancements

### Search Quality

| Technique | Description | Complexity |
|-----------|-------------|------------|
| **BM25** | Replace fuzzy matching with proper BM25 for lexical scoring | Medium |
| **Cross-Encoder Reranking** | Use `cross-encoder/ms-marco-MiniLM-L-6-v2` to rerank top-k results | Medium |
| **Query Expansion** | Use synonyms/WordNet or LLM to expand queries | Medium |
| **Hybrid Fusion (RRF)** | Reciprocal Rank Fusion instead of weighted sum | Low |
| **Multi-Vector Retrieval** | ColBERT-style late interaction for better matching | High |

### Embedding Models

| Model | Use Case | Size |
|-------|----------|------|
| `all-MiniLM-L6-v2` | Current default, fast & good | 80MB |
| `all-mpnet-base-v2` | Better quality, slower | 420MB |
| `e5-large-v2` | State-of-art retrieval | 1.3GB |
| `bge-large-en-v1.5` | Best open-source retrieval | 1.3GB |
| `nomic-embed-text-v1.5` | Long context (8192 tokens) | 550MB |
| **OpenAI `text-embedding-3-small`** | Best quality, API cost | API |
| **Cohere `embed-v3`** | Multilingual, compression | API |

### Scalability

| Tool | Purpose |
|------|---------|
| **Qdrant** | Production vector DB with filtering |
| **Milvus** | Distributed vector search |
| **Pinecone** | Managed vector DB |
| **pgvector** | PostgreSQL extension for vectors |
| **LanceDB** | Embedded vector DB (like DuckDB for vectors) |

### AI/LLM Integration

| Feature | Description |
|---------|-------------|
| **RAG Pipeline** | Feed search results to LLM for answer generation |
| **Query Understanding** | Use LLM to parse intent, extract entities |
| **Hypothetical Document Embeddings (HyDE)** | Generate hypothetical answer, embed that instead |
| **Self-Query Retrieval** | LLM generates structured filters from natural language |
| **Agentic Search** | LLM decides when to search, what to search, iterates |

### Advanced Features

| Feature | Description |
|---------|-------------|
| **Faceted Search** | Filter by metadata (date, author, category) |
| **Snippet Highlighting** | Show matching text snippets in results |
| **Typo Tolerance** | Handle misspellings gracefully |
| **Personalization** | User-specific ranking based on history |
| **A/B Testing** | Compare different ranking strategies |
| **Query Autocomplete** | Suggest queries as user types |
| **Semantic Caching** | Cache similar queries to reduce latency |
| **Chunking Strategies** | Sentence, paragraph, or sliding window chunking |
| **Parent Document Retrieval** | Return full doc when chunk matches |

### Observability

| Tool | Purpose |
|------|---------|
| **LangSmith** | Trace RAG pipelines |
| **Weights & Biases** | Track embedding model experiments |
| **Prometheus + Grafana** | Monitor latency, throughput |

### Recommended Next Steps

1. **Add BM25** - Replace fuzzy matching with `rank_bm25` for proper lexical scoring
2. **Cross-Encoder Reranking** - Rerank top-20 with cross-encoder for top-5
3. **Chunking** - Split large documents into paragraphs before indexing
4. **Metadata Filtering** - Add date/category filters to DuckDB queries
5. **RAG Integration** - Connect to OpenAI/Anthropic for answer generation

---

## Tech Stack

- **Python 3.x**
- **sentence-transformers** - Embeddings
- **DuckDB** - Document storage
- **FAISS** - Vector indexing (optional)
- **FastAPI** - REST API
- **Polars** - DataFrames
- **numba** - JIT-compiled cosine similarity
- **rapidfuzz** - Fuzzy string matching
- **watchdog** - File system monitoring
- **Streamlit** - Web UI (optional)
- **Redis** - Distributed caching (optional)
- **OpenAI/Anthropic** - RAG integration (optional)

## CLI Usage

```bash
# Search
python -m search_engine search "your query" -k 5

# Index from directory
python -m search_engine index data/

# Add to existing index
python -m search_engine add data/new_docs/

# Show statistics
python -m search_engine stats

# Export/import index
python -m search_engine export -o backup.json
python -m search_engine import -i backup.json

# Start API server
python -m search_engine serve --port 8000
```

## Docker

```bash
# Build and run
docker-compose up -d

# With Redis caching
docker-compose --profile with-redis up -d

# With Streamlit UI
docker-compose --profile with-ui up -d
```

## Web UI

```bash
# Run Streamlit UI
streamlit run ui.py
```

Open http://localhost:8501 for the web interface.

## License

MIT
